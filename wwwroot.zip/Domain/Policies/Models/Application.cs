using Mantis.Domain.Clients.Models;
using Mantis.Domain.Shared;
using System.Net;

namespace Mantis.Domain.Policies.Models
{
    public class Application
    {
        public int ApplicationId { get; set; }
        public DateTime ApplicationDate { get; set; }

    }
}
